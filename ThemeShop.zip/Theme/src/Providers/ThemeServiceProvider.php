    <?php
     
    namespace Theme\Providers;
     
    use Plenty\Plugin\ServiceProvider;
     
    class ThemeServiceProvider extends ServiceProvider
    {
     
    	/**
    	 * Register the service provider.
    	 */
    	public function register()
    	{
     
    	}
    }